/**
 * =============================================================================
 * CALENDAR HOOK
 * =============================================================================
 * This custom hook manages calendar state including events, selected date,
 * view mode, and filtering. It provides methods for CRUD operations on events.
 * =============================================================================
 */

import { useState, useCallback, useMemo } from 'react';
import type { 
  CalendarEvent, 
  CalendarView, 
  EventCategory,
  CalendarState 
} from '@/types';

/**
 * Generate sample events for demonstration
 * These would normally come from an API or database
 */
const generateSampleEvents = (): CalendarEvent[] => {
  const today = new Date();
  const events: CalendarEvent[] = [];
  
  // Sample event data - spread across multiple days and weeks
  const sampleEvents = [
    // Today's events
    { title: 'Team Standup', description: 'Daily team sync meeting', category: 'meeting' as EventCategory, startHour: 9, duration: 1, dayOffset: 0 },
    { title: 'Code Review', description: 'Review pull requests', category: 'task' as EventCategory, startHour: 10, duration: 1.5, dayOffset: 0 },
    { title: 'Lunch Break', description: '', category: 'personal' as EventCategory, startHour: 12, duration: 1, dayOffset: 0 },
    { title: 'Design Review', description: 'UI/UX design feedback', category: 'meeting' as EventCategory, startHour: 14, duration: 1.5, dayOffset: 0 },
    
    // Tomorrow's events
    { title: 'Project Planning', description: 'Q2 roadmap discussion', category: 'planning' as EventCategory, startHour: 9, duration: 2, dayOffset: 1 },
    { title: 'Client Call', description: 'Weekly check-in', category: 'meeting' as EventCategory, startHour: 13, duration: 1, dayOffset: 1 },
    { title: 'Bug Fixes', description: 'Priority issues', category: 'task' as EventCategory, startHour: 15, duration: 2, dayOffset: 1 },
    
    // Day after tomorrow
    { title: 'Sprint Planning', description: 'Plan next sprint', category: 'planning' as EventCategory, startHour: 10, duration: 2, dayOffset: 2 },
    { title: '1-on-1 Meeting', description: 'With manager', category: 'meeting' as EventCategory, startHour: 14, duration: 0.5, dayOffset: 2 },
    { title: 'Code Deployment', description: 'Deploy to production', category: 'task' as EventCategory, startHour: 16, duration: 1, dayOffset: 2 },
    
    // Later in the week
    { title: 'Team Lunch', description: 'Monthly team lunch', category: 'personal' as EventCategory, startHour: 12, duration: 1.5, dayOffset: 3 },
    { title: 'Demo Presentation', description: 'Showcase new features', category: 'meeting' as EventCategory, startHour: 14, duration: 1, dayOffset: 3 },
    
    { title: 'Sprint Retrospective', description: 'Team retrospective session', category: 'meeting' as EventCategory, startHour: 10, duration: 1.5, dayOffset: 4 },
    { title: 'Performance Review', description: 'Quarterly review', category: 'exam' as EventCategory, startHour: 13, duration: 1, dayOffset: 4 },
    
    // Weekend events
    { title: 'Study Session', description: 'Learn new framework', category: 'personal' as EventCategory, startHour: 10, duration: 3, dayOffset: 5 },
    { title: 'Gym', description: 'Weekly workout', category: 'personal' as EventCategory, startHour: 18, duration: 1.5, dayOffset: 5 },
    
    { title: 'Family Dinner', description: 'Sunday dinner', category: 'personal' as EventCategory, startHour: 17, duration: 2, dayOffset: 6 },
    
    // Previous day
    { title: 'Documentation', description: 'Update API documentation', category: 'task' as EventCategory, startHour: 11, duration: 2, dayOffset: -1 },
    { title: 'Team Meeting', description: 'Weekly sync', category: 'meeting' as EventCategory, startHour: 15, duration: 1, dayOffset: -1 },
    
    // Next week events
    { title: 'All Hands', description: 'Company-wide meeting', category: 'meeting' as EventCategory, startHour: 9, duration: 1.5, dayOffset: 7 },
    { title: 'Workshop', description: 'React advanced patterns', category: 'planning' as EventCategory, startHour: 13, duration: 3, dayOffset: 8 },
    { title: 'Deadline', description: 'Project submission', category: 'exam' as EventCategory, startHour: 17, duration: 0.5, dayOffset: 9 },
    { title: 'Interview', description: 'Candidate screening', category: 'meeting' as EventCategory, startHour: 10, duration: 1, dayOffset: 10 },
    
    // More events for month view
    { title: 'Release Planning', description: 'Next release cycle', category: 'planning' as EventCategory, startHour: 11, duration: 2, dayOffset: 12 },
    { title: 'Security Audit', description: 'Quarterly security check', category: 'task' as EventCategory, startHour: 14, duration: 2, dayOffset: 14 },
    { title: 'Hackathon', description: '24-hour coding event', category: 'other' as EventCategory, startHour: 9, duration: 12, dayOffset: 16 },
    { title: 'Training', description: 'New employee onboarding', category: 'planning' as EventCategory, startHour: 10, duration: 4, dayOffset: 18 },
    { title: 'Board Meeting', description: 'Executive review', category: 'meeting' as EventCategory, startHour: 13, duration: 2, dayOffset: 20 },
    { title: 'Code Freeze', description: 'No more changes', category: 'exam' as EventCategory, startHour: 18, duration: 0.5, dayOffset: 22 },
    { title: 'Retrospective', description: 'Month-end review', category: 'meeting' as EventCategory, startHour: 10, duration: 1.5, dayOffset: 25 },
    { title: 'Team Building', description: 'Outdoor activities', category: 'personal' as EventCategory, startHour: 14, duration: 4, dayOffset: 27 },
  ];

  sampleEvents.forEach((event, index) => {
    const date = new Date(today);
    date.setDate(date.getDate() + event.dayOffset);
    
    const startTime = new Date(date);
    startTime.setHours(event.startHour, 0, 0, 0);
    
    const endTime = new Date(startTime);
    endTime.setHours(endTime.getHours() + Math.floor(event.duration));
    endTime.setMinutes((event.duration % 1) * 60);

    events.push({
      id: `event-${index}`,
      title: event.title,
      description: event.description,
      startTime,
      endTime,
      category: event.category,
      location: 'Conference Room A',
    });
  });

  return events;
};

/**
 * Custom hook for managing calendar state and operations
 * 
 * @returns Calendar state and methods for event management
 */
export function useCalendar() {
  // Initialize calendar state with sample data
  const [state, setState] = useState<CalendarState>({
    selectedDate: new Date(),
    view: 'week',
    events: generateSampleEvents(),
    selectedEvent: null,
    filterCategories: [],
  });

  /**
   * Set the currently selected date
   */
  const setSelectedDate = useCallback((date: Date) => {
    setState(prev => ({ ...prev, selectedDate: date }));
  }, []);

  /**
   * Change the calendar view mode (day/week/month/agenda)
   */
  const setView = useCallback((view: CalendarView) => {
    setState(prev => ({ ...prev, view }));
  }, []);

  /**
   * Add a new event to the calendar
   */
  const addEvent = useCallback((event: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...event,
      id: `event-${Date.now()}`,
    };
    setState(prev => ({
      ...prev,
      events: [...prev.events, newEvent],
    }));
  }, []);

  /**
   * Update an existing event
   */
  const updateEvent = useCallback((eventId: string, updates: Partial<CalendarEvent>) => {
    setState(prev => ({
      ...prev,
      events: prev.events.map(event =>
        event.id === eventId ? { ...event, ...updates } : event
      ),
    }));
  }, []);

  /**
   * Delete an event from the calendar
   */
  const deleteEvent = useCallback((eventId: string) => {
    setState(prev => ({
      ...prev,
      events: prev.events.filter(event => event.id !== eventId),
      selectedEvent: prev.selectedEvent?.id === eventId ? null : prev.selectedEvent,
    }));
  }, []);

  /**
   * Select an event for viewing/editing
   */
  const selectEvent = useCallback((event: CalendarEvent | null) => {
    setState(prev => ({ ...prev, selectedEvent: event }));
  }, []);

  /**
   * Toggle a category filter
   */
  const toggleCategoryFilter = useCallback((category: EventCategory) => {
    setState(prev => ({
      ...prev,
      filterCategories: prev.filterCategories.includes(category)
        ? prev.filterCategories.filter(c => c !== category)
        : [...prev.filterCategories, category],
    }));
  }, []);

  /**
   * Clear all category filters
   */
  const clearFilters = useCallback(() => {
    setState(prev => ({ ...prev, filterCategories: [] }));
  }, []);

  /**
   * Navigate to the next period (day/week/month)
   */
  const navigateNext = useCallback(() => {
    setState(prev => {
      const newDate = new Date(prev.selectedDate);
      switch (prev.view) {
        case 'day':
          newDate.setDate(newDate.getDate() + 1);
          break;
        case 'week':
          newDate.setDate(newDate.getDate() + 7);
          break;
        case 'month':
          newDate.setMonth(newDate.getMonth() + 1);
          break;
        default:
          break;
      }
      return { ...prev, selectedDate: newDate };
    });
  }, []);

  /**
   * Navigate to the previous period (day/week/month)
   */
  const navigatePrevious = useCallback(() => {
    setState(prev => {
      const newDate = new Date(prev.selectedDate);
      switch (prev.view) {
        case 'day':
          newDate.setDate(newDate.getDate() - 1);
          break;
        case 'week':
          newDate.setDate(newDate.getDate() - 7);
          break;
        case 'month':
          newDate.setMonth(newDate.getMonth() - 1);
          break;
        default:
          break;
      }
      return { ...prev, selectedDate: newDate };
    });
  }, []);

  /**
   * Navigate to today
   */
  const navigateToToday = useCallback(() => {
    setState(prev => ({ ...prev, selectedDate: new Date() }));
  }, []);

  /**
   * Filtered events based on selected categories
   */
  const filteredEvents = useMemo(() => {
    if (state.filterCategories.length === 0) {
      return state.events;
    }
    return state.events.filter(event => 
      state.filterCategories.includes(event.category)
    );
  }, [state.events, state.filterCategories]);

  /**
   * Get events for a specific date
   */
  const getEventsForDate = useCallback((date: Date) => {
    return filteredEvents.filter(event => {
      const eventDate = new Date(event.startTime);
      return (
        eventDate.getDate() === date.getDate() &&
        eventDate.getMonth() === date.getMonth() &&
        eventDate.getFullYear() === date.getFullYear()
      );
    });
  }, [filteredEvents]);

  return {
    // State
    selectedDate: state.selectedDate,
    view: state.view,
    events: state.events,
    filteredEvents,
    selectedEvent: state.selectedEvent,
    filterCategories: state.filterCategories,
    // Actions
    setSelectedDate,
    setView,
    addEvent,
    updateEvent,
    deleteEvent,
    selectEvent,
    toggleCategoryFilter,
    clearFilters,
    navigateNext,
    navigatePrevious,
    navigateToToday,
    getEventsForDate,
  };
}
