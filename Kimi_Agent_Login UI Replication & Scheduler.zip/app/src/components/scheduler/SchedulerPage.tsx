/**
 * =============================================================================
 * SCHEDULER PAGE COMPONENT
 * =============================================================================
 * This is the main scheduling system page that combines the sidebar,
 * mini calendar, and main calendar view. It provides an IDE-style layout
 * with a collapsible left sidebar and a comprehensive calendar interface.
 * =============================================================================
 */

import React, { useState } from 'react';
import { Sidebar } from './Sidebar';
import { MiniCalendar } from './MiniCalendar';
import { CalendarView } from './CalendarView';
import { useCalendar } from '@/hooks/useCalendar';
import type { CalendarEvent } from '@/types';

/**
 * Props for the SchedulerPage component
 */
interface SchedulerPageProps {
  /** Current user's name */
  userName: string;
  /** Callback when user logs out */
  onLogout: () => void;
}

/**
 * Event Detail Modal Component
 * Shows detailed information about a selected event
 */
interface EventModalProps {
  event: CalendarEvent | null;
  onClose: () => void;
  onEdit?: (event: CalendarEvent) => void;
  onDelete?: (eventId: string) => void;
}

const EventModal: React.FC<EventModalProps> = ({ event, onClose, onEdit, onDelete }) => {
  if (!event) return null;

  const categoryConfig = {
    meeting: { label: 'Meeting', color: 'bg-violet-500' },
    task: { label: 'Task', color: 'bg-blue-500' },
    reminder: { label: 'Reminder', color: 'bg-amber-500' },
    planning: { label: 'Planning', color: 'bg-emerald-500' },
    exam: { label: 'Exam', color: 'bg-red-500' },
    personal: { label: 'Personal', color: 'bg-pink-500' },
    other: { label: 'Other', color: 'bg-gray-500' },
  }[event.category];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[hsl(220,15%,10%)] rounded-xl border border-[hsl(220,12%,20%)] w-full max-w-md mx-4 overflow-hidden animate-fade-in">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[hsl(220,12%,18%)]">
          <div className="flex items-center gap-3">
            <span className={`w-3 h-3 rounded-full ${categoryConfig.color}`} />
            <h2 className="text-white text-lg font-semibold">{event.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-[hsl(220,10%,50%)] hover:text-white transition-colors"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Modal Body */}
        <div className="px-6 py-4 space-y-4">
          {/* Time */}
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 text-[hsl(220,10%,50%)] mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <p className="text-white">
                {event.startTime.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </p>
              <p className="text-[hsl(220,10%,55%)] text-sm">
                {event.startTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} - 
                {event.endTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>

          {/* Location */}
          {event.location && (
            <div className="flex items-start gap-3">
              <svg className="w-5 h-5 text-[hsl(220,10%,50%)] mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <p className="text-white">{event.location}</p>
            </div>
          )}

          {/* Description */}
          {event.description && (
            <div className="flex items-start gap-3">
              <svg className="w-5 h-5 text-[hsl(220,10%,50%)] mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
              </svg>
              <p className="text-[hsl(220,10%,70%)]">{event.description}</p>
            </div>
          )}

          {/* Category */}
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 text-[hsl(220,10%,50%)] mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
            <span className={`px-2 py-1 rounded text-xs text-white ${categoryConfig.color}`}>
              {categoryConfig.label}
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[hsl(220,12%,18%)] bg-[hsl(220,15%,8%)]">
          <button
            onClick={() => onDelete?.(event.id)}
            className="px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-md transition-colors text-sm"
          >
            Delete
          </button>
          <button
            onClick={() => onEdit?.(event)}
            className="px-4 py-2 bg-[hsl(250,85%,65%)] hover:bg-[hsl(250,85%,60%)] text-white rounded-md transition-colors text-sm"
          >
            Edit
          </button>
        </div>
      </div>
    </div>
  );
};

/**
 * Main SchedulerPage Component
 * Combines sidebar, mini calendar, and main calendar view
 */
export const SchedulerPage: React.FC<SchedulerPageProps> = ({ userName, onLogout }) => {
  // Active section state for sidebar
  const [activeSection, setActiveSection] = useState('calendar');
  
  // Calendar state from custom hook
  const {
    selectedDate,
    view,
    filteredEvents,
    selectedEvent,
    setSelectedDate,
    setView,
    selectEvent,
    navigateNext,
    navigatePrevious,
    navigateToToday,
    deleteEvent,
  } = useCalendar();

  /**
   * Handle event click - open event detail modal
   */
  const handleEventClick = (event: CalendarEvent) => {
    selectEvent(event);
  };

  /**
   * Handle event deletion
   */
  const handleDeleteEvent = (eventId: string) => {
    deleteEvent(eventId);
    selectEvent(null);
  };

  return (
    <div className="h-screen flex bg-[hsl(220,15%,6%)] overflow-hidden">
      {/* Left Sidebar */}
      <Sidebar
        activeSection={activeSection}
        onSectionChange={setActiveSection}
        userName={userName}
        onLogout={onLogout}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-14 bg-[hsl(220,15%,8%)] border-b border-[hsl(220,12%,14%)] flex items-center justify-between px-4">
          {/* Breadcrumb / Current Location */}
          <div className="flex items-center gap-2 text-sm">
            <span className="text-[hsl(220,10%,50%)]">NTI Gymnasiet Sundsvall</span>
            <span className="text-[hsl(220,10%,40%)]">/</span>
            <span className="text-white">EE24</span>
          </div>

          {/* Right side actions */}
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-[hsl(220,12%,16%)] rounded-md transition-colors">
              <svg className="w-5 h-5 text-[hsl(220,10%,55%)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </button>
            <div className="flex items-center gap-2 pl-3 border-l border-[hsl(220,12%,18%)]">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                <span className="text-white text-sm font-medium">
                  {userName.charAt(0).toUpperCase()}
                </span>
              </div>
              <span className="text-white text-sm">{userName}</span>
            </div>
          </div>
        </header>

        {/* Content Grid */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Mini Calendar and Filters */}
          <div className="w-72 bg-[hsl(220,15%,8%)] border-r border-[hsl(220,12%,14%)] overflow-y-auto scrollbar-dark p-4">
            {/* Mini Calendar */}
            <MiniCalendar
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              datesWithEvents={filteredEvents.map(e => e.startTime)}
            />

            {/* Quick Stats */}
            <div className="mt-6 space-y-3">
              <h3 className="text-[hsl(220,10%,50%)] text-xs font-medium uppercase tracking-wider">
                This Week
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[hsl(220,12%,14%)] rounded-lg p-3">
                  <div className="text-2xl font-bold text-white">{filteredEvents.length}</div>
                  <div className="text-[hsl(220,10%,50%)] text-xs">Events</div>
                </div>
                <div className="bg-[hsl(220,12%,14%)] rounded-lg p-3">
                  <div className="text-2xl font-bold text-[hsl(250,85%,65%)]">3</div>
                  <div className="text-[hsl(220,10%,50%)] text-xs">Tasks</div>
                </div>
              </div>
            </div>

            {/* Upcoming Events List */}
            <div className="mt-6">
              <h3 className="text-[hsl(220,10%,50%)] text-xs font-medium uppercase tracking-wider mb-3">
                Upcoming
              </h3>
              <div className="space-y-2">
                {filteredEvents.slice(0, 3).map((event) => (
                  <div
                    key={event.id}
                    onClick={() => handleEventClick(event)}
                    className="p-3 bg-[hsl(220,12%,14%)] hover:bg-[hsl(220,12%,18%)] rounded-lg cursor-pointer transition-colors"
                  >
                    <div className="text-white text-sm font-medium truncate">{event.title}</div>
                    <div className="text-[hsl(220,10%,50%)] text-xs mt-1">
                      {event.startTime.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      {' · '}
                      {event.startTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Main Calendar View */}
          <div className="flex-1 min-w-0">
            <CalendarView
              selectedDate={selectedDate}
              view={view}
              events={filteredEvents}
              onDateChange={setSelectedDate}
              onViewChange={setView}
              onEventClick={handleEventClick}
              onNext={navigateNext}
              onPrevious={navigatePrevious}
              onToday={navigateToToday}
            />
          </div>
        </div>
      </div>

      {/* Event Detail Modal */}
      <EventModal
        event={selectedEvent}
        onClose={() => selectEvent(null)}
        onDelete={handleDeleteEvent}
      />
    </div>
  );
};

export default SchedulerPage;
