/**
 * =============================================================================
 * LOGIN PAGE COMPONENT
 * =============================================================================
 * This component replicates the exact Volt login UI design.
 * It features a dark theme with purple accents, custom input fields,
 * and a clean, centered layout.
 * =============================================================================
 */

import React, { useState } from 'react';
import { User, Key, Eye, EyeOff, ArrowRight, Minus, Square, X } from 'lucide-react';
import type { LoginCredentials } from '@/types';

/**
 * Props for the LoginPage component
 */
interface LoginPageProps {
  /** Callback when user submits login form */
  onLogin: (credentials: LoginCredentials) => void;
  /** Loading state during authentication */
  isLoading?: boolean;
  /** Error message to display */
  error?: string | null;
}

/**
 * Volt Logo Component
 * Displays the stylized Volt lightning bolt logo
 */
const VoltLogo: React.FC = () => (
  <div className="flex items-center justify-center mb-6">
    <svg 
      width="48" 
      height="48" 
      viewBox="0 0 48 48" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className="transform -rotate-12"
    >
      {/* Lightning bolt shape */}
      <path
        d="M28 4L12 24H22L18 44L36 20H24L28 4Z"
        fill="url(#volt-gradient)"
        stroke="url(#volt-gradient)"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient id="volt-gradient" x1="12" y1="4" x2="36" y2="44" gradientUnits="userSpaceOnUse">
          <stop stopColor="#8B5CF6" />
          <stop offset="1" stopColor="#A78BFA" />
        </linearGradient>
      </defs>
    </svg>
    <span className="text-2xl font-bold text-white ml-2">Volt</span>
  </div>
);

/**
 * Window Title Bar Component
 * Simulates a native window title bar with controls
 */
const WindowTitleBar: React.FC = () => (
  <div className="flex items-center justify-between px-4 py-3 bg-[hsl(220,15%,6%)] border-b border-[hsl(220,12%,14%)]">
    {/* Left side - Window title */}
    <div className="flex items-center gap-2">
      <svg 
        width="16" 
        height="16" 
        viewBox="0 0 48 48" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="transform -rotate-12"
      >
        <path
          d="M28 4L12 24H22L18 44L36 20H24L28 4Z"
          fill="#8B5CF6"
          stroke="#8B5CF6"
          strokeWidth="2"
          strokeLinejoin="round"
        />
      </svg>
      <span className="text-sm text-[hsl(220,10%,70%)]">Sign In</span>
    </div>
    
    {/* Right side - Window controls */}
    <div className="flex items-center gap-2">
      <button className="p-1.5 hover:bg-[hsl(220,12%,18%)] rounded transition-colors">
        <Minus className="w-4 h-4 text-[hsl(220,10%,60%)]" />
      </button>
      <button className="p-1.5 hover:bg-[hsl(220,12%,18%)] rounded transition-colors">
        <Square className="w-3.5 h-3.5 text-[hsl(220,10%,60%)]" />
      </button>
      <button className="p-1.5 hover:bg-red-600 rounded transition-colors">
        <X className="w-4 h-4 text-[hsl(220,10%,60%)] hover:text-white" />
      </button>
    </div>
  </div>
);

/**
 * Custom Input Field Component
 * Styled input with icon support for the Volt login form
 */
interface InputFieldProps {
  /** Input type (text, password, etc.) */
  type: string;
  /** Input value */
  value: string;
  /** Change handler */
  onChange: (value: string) => void;
  /** Placeholder text */
  placeholder: string;
  /** Icon component to display */
  icon: React.ReactNode;
  /** Optional toggle button (for password visibility) */
  toggleButton?: React.ReactNode;
  /** Whether the field has an error */
  hasError?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({
  type,
  value,
  onChange,
  placeholder,
  icon,
  toggleButton,
  hasError,
}) => (
  <div className="relative">
    {/* Left icon */}
    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-[hsl(220,10%,45%)]">
      {icon}
    </div>
    
    {/* Input field */}
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={`
        w-full h-12 pl-12 pr-${toggleButton ? '12' : '4'} rounded-lg
        bg-[hsl(220,12%,14%)] border text-white text-sm
        placeholder:text-[hsl(220,10%,45%)]
        focus:outline-none focus:border-[hsl(250,85%,65%)] focus:ring-1 focus:ring-[hsl(250,85%,65%)]
        transition-all duration-200
        ${hasError ? 'border-red-500' : 'border-[hsl(220,12%,20%)]'}
      `}
    />
    
    {/* Right toggle button (e.g., password visibility) */}
    {toggleButton && (
      <div className="absolute right-4 top-1/2 -translate-y-1/2">
        {toggleButton}
      </div>
    )}
  </div>
);

/**
 * Main Login Page Component
 * Replicates the exact Volt login UI design
 */
export const LoginPage: React.FC<LoginPageProps> = ({ 
  onLogin, 
  isLoading = false, 
  error = null 
}) => {
  // Form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  /**
   * Handle form submission
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({ email, password });
  };

  return (
    <div className="min-h-screen bg-[hsl(220,15%,6%)] flex flex-col">
      {/* Window Title Bar */}
      <WindowTitleBar />
      
      {/* Main Login Content */}
      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md animate-fade-in">
          {/* Logo and Header */}
          <div className="text-center mb-10">
            <VoltLogo />
            <h1 className="text-3xl font-bold text-white mb-2">
              Welcome to Volt
            </h1>
            <p className="text-[hsl(220,10%,55%)] text-sm">
              Sign in to access your Lua development environment
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email/Username Field */}
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Username or Email
              </label>
              <InputField
                type="text"
                value={email}
                onChange={setEmail}
                placeholder="user@volt.bz"
                icon={<User className="w-5 h-5" />}
                hasError={!!error}
              />
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Password
              </label>
              <InputField
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={setPassword}
                placeholder="********"
                icon={<Key className="w-5 h-5" />}
                hasError={!!error}
                toggleButton={
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[hsl(220,10%,45%)] hover:text-white transition-colors"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                }
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="text-red-400 text-sm text-center">
                {error}
              </div>
            )}

            {/* Sign In Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="
                w-full h-12 rounded-lg
                bg-[hsl(220,12%,22%)] hover:bg-[hsl(220,12%,28%)]
                text-white font-medium
                flex items-center justify-center gap-2
                transition-all duration-200
                disabled:opacity-50 disabled:cursor-not-allowed
              "
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  Sign In
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Forgot Password Link */}
          <div className="mt-6 text-center">
            <a 
              href="#" 
              className="text-[hsl(220,10%,60%)] hover:text-white text-sm transition-colors"
            >
              Forgot your password?
            </a>
          </div>

          {/* Create Account Link */}
          <div className="mt-8 text-center">
            <span className="text-[hsl(220,10%,55%)] text-sm">
              Don&apos;t have an account?{' '}
            </span>
            <a 
              href="#" 
              className="text-[hsl(250,85%,65%)] hover:text-[hsl(250,85%,75%)] text-sm font-medium transition-colors"
            >
              Create one here
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
