/**
 * =============================================================================
 * SIDEBAR COMPONENT
 * =============================================================================
 * This component provides the main navigation sidebar for the scheduler.
 * It's inspired by IDE layouts (like VS Code) with collapsible sections,
 * icons, and a clean hierarchical structure.
 * =============================================================================
 */

import React, { useState } from 'react';
import { 
  Calendar, 
  CheckSquare, 
  Clock, 
  FileText, 
  BookOpen, 
  GraduationCap,
  ChevronDown,
  ChevronRight,
  LogOut,
  Search,
  Bell,
  LayoutDashboard
} from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Navigation item structure
 */
interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
  children?: NavItem[];
}

/**
 * Props for the Sidebar component
 */
interface SidebarProps {
  /** Currently active section ID */
  activeSection: string;
  /** Callback when a section is selected */
  onSectionChange: (sectionId: string) => void;
  /** User's display name */
  userName: string;
  /** Callback for logout action */
  onLogout: () => void;
}

/**
 * Navigation data structure
 * Defines the sidebar menu hierarchy
 */
const NAVIGATION_ITEMS: NavItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
  },
  {
    id: 'schedule',
    label: 'Schedule & Calendar',
    icon: Calendar,
    children: [
      { id: 'calendar', label: 'Calendar View', icon: Calendar },
      { id: 'bookings', label: 'Bookings', icon: Clock },
    ],
  },
  {
    id: 'tasks',
    label: 'Tasks',
    icon: CheckSquare,
    badge: 3,
  },
  {
    id: 'planning',
    label: 'Planning',
    icon: FileText,
  },
  {
    id: 'courses',
    label: 'Courses',
    icon: BookOpen,
  },
  {
    id: 'exams',
    label: 'Exams & Assessments',
    icon: GraduationCap,
  },
];

/**
 * Sidebar Navigation Item Component
 * Renders a single navigation item with optional children
 */
interface SidebarNavItemProps {
  item: NavItem;
  isActive: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  onSelect: () => void;
  depth?: number;
}

const SidebarNavItem: React.FC<SidebarNavItemProps> = ({
  item,
  isActive,
  isExpanded,
  onToggle,
  onSelect,
  depth = 0,
}) => {
  const hasChildren = item.children && item.children.length > 0;
  const Icon = item.icon;

  return (
    <div>
      {/* Main item */}
      <div
        onClick={hasChildren ? onToggle : onSelect}
        className={cn(
          'flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer',
          'text-[hsl(220,10%,65%)] hover:text-white hover:bg-[hsl(220,12%,16%)]',
          'transition-all duration-150',
          isActive && 'text-white bg-[hsl(220,12%,18%)]',
          depth > 0 && 'ml-4'
        )}
      >
        {/* Expand/collapse chevron for items with children */}
        {hasChildren && (
          <span className="w-4 h-4 flex items-center justify-center">
            {isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </span>
        )}
        
        {/* Icon */}
        {!hasChildren && <span className="w-4" />}
        <Icon className="w-5 h-5" />
        
        {/* Label */}
        <span className="flex-1 text-sm">{item.label}</span>
        
        {/* Badge */}
        {item.badge && (
          <span className="px-2 py-0.5 text-xs bg-[hsl(250,85%,65%)] text-white rounded-full">
            {item.badge}
          </span>
        )}
      </div>

      {/* Child items */}
      {hasChildren && isExpanded && (
        <div className="mt-1 space-y-0.5">
          {item.children!.map((child) => (
            <div
              key={child.id}
              onClick={() => onSelect()}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer ml-8',
                'text-[hsl(220,10%,55%)] hover:text-white hover:bg-[hsl(220,12%,16%)]',
                'transition-all duration-150',
                isActive && child.id === item.children![0].id && 'text-white bg-[hsl(220,12%,18%)]'
              )}
            >
              <child.icon className="w-4 h-4" />
              <span className="text-sm">{child.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/**
 * Main Sidebar Component
 * Provides navigation and user profile section
 */
export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSectionChange,
  userName,
  onLogout,
}) => {
  // Track expanded sections
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(['schedule'])
  );

  /**
   * Toggle section expansion
   */
  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(sectionId)) {
        next.delete(sectionId);
      } else {
        next.add(sectionId);
      }
      return next;
    });
  };

  return (
    <aside className="w-64 h-full bg-[hsl(220,15%,8%)] border-r border-[hsl(220,12%,14%)] flex flex-col">
      {/* Header / Logo Area */}
      <div className="p-4 border-b border-[hsl(220,12%,14%)]">
        <div className="flex items-center gap-3">
          {/* Volt Logo */}
          <svg 
            width="28" 
            height="28" 
            viewBox="0 0 48 48" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
            className="transform -rotate-12"
          >
            <path
              d="M28 4L12 24H22L18 44L36 20H24L28 4Z"
              fill="#8B5CF6"
              stroke="#8B5CF6"
              strokeWidth="2"
              strokeLinejoin="round"
            />
          </svg>
          <div>
            <h2 className="text-white font-semibold text-sm">Volt Scheduler</h2>
            <p className="text-[hsl(220,10%,50%)] text-xs">EE24</p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-3 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(220,10%,45%)]" />
          <input
            type="text"
            placeholder="Search..."
            className="
              w-full h-9 pl-9 pr-4 rounded-md
              bg-[hsl(220,12%,14%)] border border-[hsl(220,12%,20%)]
              text-white text-sm placeholder:text-[hsl(220,10%,45%)]
              focus:outline-none focus:border-[hsl(250,85%,65%)]
              transition-all duration-200
            "
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[hsl(220,10%,40%)] text-xs">
            Ctrl+K
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto scrollbar-dark">
        {NAVIGATION_ITEMS.map((item) => (
          <SidebarNavItem
            key={item.id}
            item={item}
            isActive={activeSection === item.id}
            isExpanded={expandedSections.has(item.id)}
            onToggle={() => toggleSection(item.id)}
            onSelect={() => onSectionChange(item.id)}
          />
        ))}
      </nav>

      {/* Filter Section */}
      <div className="px-3 py-3 border-t border-[hsl(220,12%,14%)]">
        <h3 className="text-[hsl(220,10%,50%)] text-xs font-medium uppercase tracking-wider mb-3 px-3">
          Show
        </h3>
        <div className="space-y-2">
          {[
            { id: 'schedule', label: 'Schedule', color: 'bg-violet-500' },
            { id: 'bookings', label: 'Bookings', color: 'bg-blue-500' },
            { id: 'personal', label: 'Personal', color: 'bg-pink-500' },
            { id: 'school', label: 'School Events', color: 'bg-emerald-500' },
            { id: 'calendar', label: 'Calendar Events', color: 'bg-amber-500' },
            { id: 'planning', label: 'Planning', color: 'bg-cyan-500' },
            { id: 'tasks', label: 'Tasks & Exams', color: 'bg-red-500' },
          ].map((filter) => (
            <label
              key={filter.id}
              className="flex items-center gap-3 px-3 py-1.5 cursor-pointer hover:bg-[hsl(220,12%,14%)] rounded-md transition-colors"
            >
              <input
                type="checkbox"
                defaultChecked
                className="w-4 h-4 rounded border-[hsl(220,12%,25%)] bg-[hsl(220,12%,14%)] text-[hsl(250,85%,65%)] focus:ring-[hsl(250,85%,65%)]"
              />
              <span className={`w-2.5 h-2.5 rounded-full ${filter.color}`} />
              <span className="text-[hsl(220,10%,70%)] text-sm">{filter.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* User Profile Section */}
      <div className="p-3 border-t border-[hsl(220,12%,14%)]">
        <div className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-[hsl(220,12%,14%)] cursor-pointer transition-colors">
          {/* User Avatar */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <span className="text-white text-sm font-medium">
              {userName.charAt(0).toUpperCase()}
            </span>
          </div>
          
          {/* User Info */}
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">{userName}</p>
            <p className="text-[hsl(220,10%,50%)] text-xs truncate">Online</p>
          </div>
          
          {/* Actions */}
          <div className="flex items-center gap-1">
            <button className="p-1.5 hover:bg-[hsl(220,12%,20%)] rounded transition-colors">
              <Bell className="w-4 h-4 text-[hsl(220,10%,55%)]" />
            </button>
            <button 
              onClick={onLogout}
              className="p-1.5 hover:bg-[hsl(220,12%,20%)] rounded transition-colors"
            >
              <LogOut className="w-4 h-4 text-[hsl(220,10%,55%)]" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
