/**
 * =============================================================================
 * VOLT SCHEDULER - MAIN APPLICATION
 * =============================================================================
 * This is the root component of the Volt Scheduler application.
 * It manages the application state, routing between login and scheduler views,
 * and provides the overall application structure.
 * 
 * The app follows a modular architecture with clear separation of concerns:
 * - Authentication (login/logout)
 * - Scheduling system (calendar, events, navigation)
 * - UI components (reusable, well-documented)
 * =============================================================================
 */

import { LoginPage } from '@/components/login/LoginPage';
import { SchedulerPage } from '@/components/scheduler/SchedulerPage';
import { useAuth } from '@/hooks/useAuth';
import './App.css';

/**
 * Main App Component
 * 
 * This component serves as the entry point for the Volt Scheduler application.
 * It conditionally renders either the LoginPage or SchedulerPage based on
 * the user's authentication state.
 */
function App() {
  // Use the authentication hook to manage user state
  const { 
    isAuthenticated, 
    user, 
    isLoading, 
    error, 
    login, 
    logout 
  } = useAuth();

  /**
   * Handle login form submission
   * Passes credentials to the auth hook's login function
   */
  const handleLogin = async (credentials: { email: string; password: string }) => {
    await login(credentials);
  };

  /**
   * Handle logout action
   * Clears authentication state and returns to login page
   */
  const handleLogout = () => {
    logout();
  };

  return (
    <div className="app-container">
      {/* 
        Conditional rendering based on authentication state:
        - If authenticated: show the scheduler interface
        - If not authenticated: show the login page
      */}
      {isAuthenticated && user ? (
        /* 
          SCHEDULER VIEW
          The main application interface with sidebar, calendar, and event management
        */
        <SchedulerPage 
          userName={user.name} 
          onLogout={handleLogout} 
        />
      ) : (
        /* 
          LOGIN VIEW
          The Volt-branded login page with dark theme and purple accents
        */
        <LoginPage 
          onLogin={handleLogin} 
          isLoading={isLoading} 
          error={error} 
        />
      )}
    </div>
  );
}

export default App;
