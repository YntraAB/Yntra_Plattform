/**
 * =============================================================================
 * AUTHENTICATION HOOK
 * =============================================================================
 * This custom hook manages user authentication state and provides
 * login/logout functionality for the Volt Scheduler application.
 * =============================================================================
 */

import { useState, useCallback } from 'react';
import type { User, LoginCredentials, AuthState } from '@/types';

/**
 * Mock user data for demonstration purposes
 * In a real application, this would come from an API/database
 */
const MOCK_USER: User = {
  id: '1',
  email: 'user@volt.bz',
  name: 'Alex Developer',
  avatar: undefined,
  role: 'user',
};

/**
 * Custom hook for managing authentication state
 * 
 * @returns Authentication state and methods
 */
export function useAuth() {
  // Initialize authentication state
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    isLoading: false,
    error: null,
  });

  /**
   * Authenticate user with provided credentials
   * Simulates API call with loading state and error handling
   * 
   * @param credentials - User login credentials
   * @returns Promise that resolves when authentication completes
   */
  const login = useCallback(async (credentials: LoginCredentials): Promise<boolean> => {
    // Set loading state
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // Simulate API delay for realistic UX
      await new Promise(resolve => setTimeout(resolve, 800));

      // Validate credentials (mock validation)
      // In production, this would be an actual API call
      if (credentials.email && credentials.password.length >= 6) {
        // Successful authentication
        setAuthState({
          isAuthenticated: true,
          user: MOCK_USER,
          isLoading: false,
          error: null,
        });
        return true;
      } else {
        // Invalid credentials
        setAuthState({
          isAuthenticated: false,
          user: null,
          isLoading: false,
          error: 'Invalid email or password. Please try again.',
        });
        return false;
      }
    } catch (error) {
      // Handle unexpected errors
      setAuthState({
        isAuthenticated: false,
        user: null,
        isLoading: false,
        error: 'An unexpected error occurred. Please try again.',
      });
      return false;
    }
  }, []);

  /**
   * Log out the current user
   * Clears authentication state
   */
  const logout = useCallback(() => {
    setAuthState({
      isAuthenticated: false,
      user: null,
      isLoading: false,
      error: null,
    });
  }, []);

  /**
   * Clear any authentication errors
   */
  const clearError = useCallback(() => {
    setAuthState(prev => ({ ...prev, error: null }));
  }, []);

  return {
    // State
    isAuthenticated: authState.isAuthenticated,
    user: authState.user,
    isLoading: authState.isLoading,
    error: authState.error,
    // Actions
    login,
    logout,
    clearError,
  };
}
